class SonAccount {
    name: string;
    surname: string;
    balanceInit: number = 0;
    constructor(_name: string, _surname: string, _balanceInit: number) {
        this.name = _name;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }

    deposit(add: number): number {
        return this.balanceInit = this.balanceInit + add;
    };

    withDraw(minus: number): number {
        return this.balanceInit = this.balanceInit - minus;
    };
}

class MotherAccount {
    name: string;
    surname: string;
    balanceInit: number = 0;
    constructor(_name: string, _surname: string, _balanceInit: number) {
        this.name = _name;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }

    deposit(add: number): number {
        return this.balanceInit = this.balanceInit + add;
    };

    withDraw(minus: number): number {
        return this.balanceInit = this.balanceInit - (minus + ((minus / 100) * 10));
    };
}

let userSon = new SonAccount('Riccardo', 'Sennati', 1000)
let userMother = new MotherAccount('Riccardo', 'Sennati', 1000)


console.log(userSon.deposit(800));
console.log(userSon.withDraw(300));
console.log(userMother.deposit(500));
console.log(userMother.withDraw(400));