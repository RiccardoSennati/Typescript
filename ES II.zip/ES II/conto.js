// SonAccount
var SonAccount = /** @class */ (function () {
    function SonAccount(_user, _surname, _balanceInit) {
        this.balanceInit = 0;
        this.user = _user;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }
    SonAccount.prototype.deposit = function (add) {
        return this.balanceInit = this.balanceInit + add;
    };
    ;
    SonAccount.prototype.withDraw = function (add) {
        return this.balanceInit = this.balanceInit - add;
    };
    ;
    return SonAccount;
}());
// MotherAccount
var MotherAccount = /** @class */ (function () {
    function MotherAccount(_user, _surname, _balanceInit) {
        this.balanceInit = 0;
        this.user = _user;
        this.surname = _surname;
        this.balanceInit = _balanceInit;
    }
    MotherAccount.prototype.deposit = function (add) {
        return this.balanceInit = this.balanceInit + add;
    };
    ;
    MotherAccount.prototype.withDraw = function (minus) {
        return this.balanceInit = this.balanceInit - minus - ((minus / 100) * 10); //prelievo con tassa
    };
    ;
    return MotherAccount;
}());
// SonAccount
var son = new SonAccount('Francesca', 'Pozzi', 150);
console.log(son.balanceInit);
console.log(son.deposit(1200)); //deposito
console.log(son.balanceInit);
console.log(son.withDraw(500)); //prelievo
// MotherAccount
var mother = new MotherAccount('Antonella', 'Buti', 1300);
console.log(mother.balanceInit);
console.log(mother.deposit(500)); //deposito
console.log(mother.balanceInit);
console.log(mother.withDraw(1000)); //prelievo