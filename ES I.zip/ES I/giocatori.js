var numeroCasuale;
var giocatore1;
var giocatore2;
var compare1;
var compare2;
numeroCasuale = diceRoll();
giocatore1 = diceRoll();
giocatore2 = diceRoll();

function diceRoll() {
    return Math.floor(Math.random() * 100);
}

console.log("Numero casuale generato = ", numeroCasuale);
console.log("Numero giocatore 1: ", giocatore1);
console.log("Numero giocatore 2: ", giocatore2);

if (giocatore1 == numeroCasuale) {
    "Giocatore 1 ha vinto!";
}
if (giocatore2 == numeroCasuale) {
    "Giocatore 2 ha vinto!";
}
if (giocatore1 != numeroCasuale && giocatore2 != numeroCasuale) {

    if (giocatore1 < numeroCasuale) {
        compare1 = numeroCasuale - giocatore1;
    }
    else {
        compare1 = giocatore1 - numeroCasuale;
    }
    ;

    if (giocatore2 < numeroCasuale) {
        compare2 = numeroCasuale - giocatore2;
    }
    else {
        compare2 = giocatore2 - numeroCasuale;
    }
    ;

    if (compare1 < compare2) {
        console.log("Nessuno dei due ha indovinato il numero casuale, ma il giocatore 1 ci è andato più vicino");
    }
    else {
        console.log("Nessuno dei due ha indovinato il numero casuale, ma il giocatore 1 ci è andato più vicino");
    }
}